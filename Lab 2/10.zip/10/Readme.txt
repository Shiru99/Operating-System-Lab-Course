# Thread Synchronization

## To run : test-zem.c

    g++ test-zem.c zemaphore.c -o test-zem -lpthread

    ./test-zem

    
## To run : test-toggle.c

    g++ test-toggle.c zemaphore.c -o test-toggle -lpthread
    
    ./test-toggle