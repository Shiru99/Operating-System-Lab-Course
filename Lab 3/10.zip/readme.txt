# Dynamic memory management

## To run : alloc.c

    gcc test_alloc.c alloc.c 

    ./a.out

    
## To run : ealloc.c

    gcc test_ealloc.c ealloc.c 

    ./a.out