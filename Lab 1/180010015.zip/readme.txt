### Building a Shell

Simple shell

## How to run

    $ gcc my_shell.c -o my_shell

    $ ./my_shell

