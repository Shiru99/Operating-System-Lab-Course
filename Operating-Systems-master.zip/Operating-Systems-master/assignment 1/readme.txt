Place the shell scripts given to you in your solution directory. Run the following command.

./master.sh my_shell.c

This script will in turn invoke separate shell scripts for parts A, B, C of the assignment. Each script will run a set of test cases on your code and print out the result of the tests. The output will help you debug your solution.

Please write to us if you find any errors with the grading script.
