# File-System

File system implementation on an emulated disk with basic operations like open/close/read and write.  

Details can be found [here](fs.pdf).
